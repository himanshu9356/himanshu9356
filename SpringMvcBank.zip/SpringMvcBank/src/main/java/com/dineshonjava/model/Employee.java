package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Employee")
public class Employee implements Serializable{

	 
	
	@Id
	 
	@Column(name = "customerid")
	private Integer customerId;
	
	@Column(name="customername")
	private String customerName;
	
	@Column(name="customerAge")
	private Integer customerAge;
	
	@Column(name="customeraddress")
	private String customerAddress;
	
	@Column(name="customeremail")
	private String customeremail;
	
	@Column(name="customerphoneno")
	private String customerphoneno;
	
	@Column(name="customercompany")
	private String customerCompany;
	
	@Column(name="customerbalance")
	private String customerBalance;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getCustomerAge() {
		return customerAge;
	}

	public void setCustomerAge(Integer customerAge) {
		this.customerAge = customerAge;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomeremail() {
		return customeremail;
	}

	public void setCustomeremail(String customeremail) {
		this.customeremail = customeremail;
	}

	public String getCustomerphoneno() {
		return customerphoneno;
	}

	public void setCustomerphoneno(String customerphoneno) {
		this.customerphoneno = customerphoneno;
	}

	public String getCustomerCompany() {
		return customerCompany;
	}

	public void setCustomerCompany(String customerCompany) {
		this.customerCompany = customerCompany;
	}

	public String getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(String customerBalance) {
		this.customerBalance = customerBalance;
	}

	

}
